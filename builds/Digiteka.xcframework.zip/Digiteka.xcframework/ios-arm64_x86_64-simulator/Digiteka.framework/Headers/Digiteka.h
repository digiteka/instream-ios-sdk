//
//  Digiteka.h
//  Digiteka
//
//  Created by INGENOSYA SA on 13/04/2021.
//  Copyright © 2021 INGENOSYA SA. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Digiteka.
FOUNDATION_EXPORT double DigitekaVersionNumber;

//! Project version string for Digiteka.
FOUNDATION_EXPORT const unsigned char DigitekaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Digiteka/PublicHeader.h>


